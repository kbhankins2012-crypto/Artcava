#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$HOME/.local/share/artcava"
DESKTOP_DIR="$HOME/.local/share/applications"
DESKTOP_FILE="$DESKTOP_DIR/artcava.desktop"

if ! command -v x-terminal-emulator >/dev/null 2>&1; then
    echo "Could not find x-terminal-emulator. Install/configure a terminal emulator first,"
    echo "or edit the Exec= line in the generated .desktop launcher for your terminal."
    exit 1
fi

mkdir -p "$APP_DIR" "$DESKTOP_DIR"
install -m 755 "$SCRIPT_DIR/Artcava.py" "$APP_DIR/Artcava.py"

cat > "$DESKTOP_FILE" <<DESKTOP
[Desktop Entry]
Version=1.0
Type=Application
Name=Artcava
Comment=Terminal audio visualizer colored by album artwork
Exec=x-terminal-emulator -e python3 "$APP_DIR/Artcava.py"
Icon=audio-x-generic
Terminal=false
Categories=AudioVideo;Audio;
DESKTOP

chmod 755 "$DESKTOP_FILE"
echo "Artcava installed. Search for 'Artcava' in your application menu."
echo "App file: $APP_DIR/Artcava.py"
echo "Launcher: $DESKTOP_FILE"
