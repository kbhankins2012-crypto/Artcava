# Artcava

**Artcava is an open-source, CAVA-inspired audio visualizer for Linux.** It displays live audio bars in your terminal and automatically colors them using the album artwork from the music currently playing.

It reads playback artwork through MPRIS with `playerctl`, captures audio from your default output's monitor with `parec` (PulseAudio or PipeWire compatibility), and uses NumPy to analyze the audio.

## Features

- Live terminal audio visualization
- Colors extracted from the currently playing track's album artwork
- Smooth bar animation and color transitions
- Keyboard settings panel: press **S** while the visualizer is running
- Color presets, including Album art, Ocean, Fire, Forest, Purple, Pink, Red, Green, Blue, and White
- Adjustable bar width, spacing, sensitivity, smoothing, and beat flash
- Settings saved between launches in `~/.config/artcava/settings.json`
- Optional debug display with `--debug`

## Requirements

- Linux with a terminal that supports 24-bit true color
- Python 3
- NumPy
- Pillow
- `playerctl`
- `parec` (provided by `pulseaudio-utils` on Debian-based systems)
- A working audio output monitor source

## Install on Debian / Debian-based Linux

Install the system dependencies:

```bash
sudo apt update
sudo apt install python3 python3-numpy python3-pil playerctl pulseaudio-utils
```

Clone the repository and enter its folder:

```bash
git clone https://github.com/YOUR-USERNAME/Artcava.git
cd Artcava
```

Run the installer:

```bash
chmod +x install.sh
./install.sh
```

The installer copies `Artcava.py` into `~/.local/share/artcava/` and creates an application-menu launcher at `~/.local/share/applications/artcava.desktop`.

Open your desktop's application menu, search for **Artcava**, and launch it. The launcher opens a terminal and runs the visualizer.

> The launcher uses `x-terminal-emulator`, which is the standard terminal launcher on many Debian-based desktops. If your system does not provide it, edit the `Exec=` line in `~/.local/share/applications/artcava.desktop` to use your terminal emulator. For Kitty, for example: `Exec=kitty --hold python3 /home/YOUR-USERNAME/.local/share/artcava/Artcava.py`.

## Run from a terminal

From the repository folder:

```bash
python3 Artcava.py
```

Show the debug information line:

```bash
python3 Artcava.py --debug
```

Use a local image or image URL as a temporary artwork source:

```bash
python3 Artcava.py /path/to/cover.jpg
```

## Controls

- **S** — open or close the settings panel
- **Up / Down** — choose a setting
- **Left / Right** — change the selected setting
- **Enter** — change the selected setting
- **Q** — quit the visualizer
- **Esc** — close the settings panel

## Python dependencies

The Python packages are listed in [`requirements.txt`](requirements.txt). On Debian, installing `python3-numpy` and `python3-pil` through `apt` is usually the simplest option. If you prefer `pip`, use a virtual environment rather than installing packages into a system-managed Python environment:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
```

The external commands `playerctl` and `parec` are still required when using a virtual environment.

## Open source license

Artcava is distributed under the **MIT License**. See [`LICENSE`](LICENSE) for the full license text. You are free to use, modify, and redistribute the project under the terms of that license.

## Contributing

Issues, bug reports, and pull requests are welcome. Please include your Linux distribution, Python version, terminal emulator, and any error output when reporting a problem.
